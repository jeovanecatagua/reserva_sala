class reserva_sala:
    def __init__(self, id, sala_reuniao, dt_reuniao, hr_inicio, hr_fim):
        self.id             = id
        self.sala_reuniao   = sala_reuniao
        self.dt_reuniao     = dt_reuniao
        self.hr_inicio      = hr_inicio
        self.hr_fim         = hr_fim