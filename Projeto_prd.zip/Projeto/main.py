import streamlit as st
import Pages.Reserva_sala_reuniao.Create as PagesCreateReserva
import Pages.Reserva_sala_reuniao.List as PagesListReserva
import streamlit_authenticator as stauth

st.title("Teste")

# def creds_entered():
#     if st.session_state["user"].strip()== "jeovane.mendes@catagua.com.br" and st.session_state["passwd"].strip() == "1":
#         st.session_state["authenticated"] = True
#     else:
#         st.session_state["authenticated"] = False
#         if not st.session_state["user"]:
#                st.warning("Insira seu e-mail")
#         elif not st.session_state["passwd"]:
#                st.warning("Insira a sua senha")
#         else:
#             st.error("Inválido Senha/Usuário :face_with_raised_eyebrow:")

# def authenticate_user():
#     if "authenticated" not in st.session_state:
#         st.text_input(label="E-mail :", value="", key="user", on_change=creds_entered)
#         st.text_input(label="Senha :", value="", key="passwd", type="password", on_change=creds_entered)
#         return False
#     else:
#             if st.session_state["authenticated"]:
#                 return True
#             else:
#                 st.text_input(label="E-mail :", value="", key="user", on_change=creds_entered)
#                 st.text_input(label="Senha :", value="", key="passwd", type="password", on_change=creds_entered)
#                 return False

# if authenticate_user():
    # st.sidebar.title('Menu')
PagePipe = st.sidebar.selectbox(
    'Tela',
    [
        'Fazer Reserva',
        'Consultar Reserva'
    ]
)

if PagePipe == 'Fazer Reserva':
    PagesCreateReserva.Incluir()

if PagePipe == 'Consultar Reserva':
    PagesListReserva.List()