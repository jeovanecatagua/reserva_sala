import streamlit as st
import Controllers.ControllersReservas as ControllersReservas
import models.reservas as reservas
import datetime as dt

ControllersReservas.create_table()

def Incluir():
    with st.form(key="incluir_reserva"):
        input_sala_reuniao = st.selectbox(
            "**Selecione a sala**",
            options=[
                "Sala 01",
                "Sala 02",
                "Sala 03",
                "Sala 04"
            ]
        )
        input_dt_reuniao = st.date_input("Escolha uma data para a reunião:", format="DD/MM/YYYY")
        horario_inicio   = st.time_input("Horário de início:", value=None)
        horario_fim      = st.time_input("Horário de fim:", value=None)

        input_button_submit = st.form_submit_button("**Enviar**")

    if input_button_submit:
        if horario_inicio >= horario_fim:
            st.error("O horário de término deve ser após o horário de início.")
            return
        reservas.sala_reuniao   = input_sala_reuniao
        reservas.dt_reuniao     = input_dt_reuniao
        reservas.hr_inicio = horario_inicio.strftime("%H:%M:%S")  # Converte para texto
        reservas.hr_fim = horario_fim.strftime("%H:%M:%S")  # Converte para texto

        ControllersReservas.Incluir(reservas)
        st.success(f"Sala de reunião {input_sala_reuniao} reservada!")