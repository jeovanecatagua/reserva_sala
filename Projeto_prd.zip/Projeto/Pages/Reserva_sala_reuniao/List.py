import streamlit as st
import Controllers.ControllersReservas as ControllersReservas
import pandas as pd


def List():
    customerList = []

    for item in ControllersReservas.selecionarTodos():
        customerList.append([item.sala_reuniao, item.dt_reuniao, item.hr_inicio, item.hr_fim])

    df = pd.DataFrame(
        customerList,
        columns=['Sala de reunião', 'Data da reserva', 'Horário de ínicio', 'Horário de fim']
    )

    st.table(df)