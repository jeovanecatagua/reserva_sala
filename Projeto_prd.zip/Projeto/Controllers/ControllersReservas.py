
import models.reservas as reservas
import sqlite3

conn = sqlite3.connect("dados_projeto.db", check_same_thread=False)
cursor = conn.cursor()

def create_table():
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tb_reserva_sala_reuniao (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            sala_reuniao TEXT NOT NULL,
            dt_reuniao   DATE NOT NULL,
            hr_inicio    TEXT NOT NULL,
            hr_fim       TEXT NOT NULL
        )
    ''')
    conn.commit()

def Incluir(insert_tb):
    cursor.execute(""" 
        INSERT INTO tb_reserva_sala_reuniao (sala_reuniao, dt_reuniao, hr_inicio, hr_fim) 
        VALUES(?, ?, ?, ?)""",
        (insert_tb.sala_reuniao, insert_tb.dt_reuniao, insert_tb.hr_inicio, insert_tb.hr_fim)
    )
    conn.commit()

def Alterar(alterar_tb):
    count = cursor.execute(""" 
    UPDATE tb_reserva_sala_reuniao
    SET 
        sala_reuniao = ?, 
        dt_reuniao   = ?,
        hr_inicio    = ?,
        hr_fim       = ?
    WHERE id = ?""",
    alterar_tb.sala_reuniao, alterar_tb.dt_reuniao, alterar_tb.hr_inicio, alterar_tb.hr_fim).rowcount
    conn.commit()

def Excluir(id):
    count = cursor.execute(""" 
    DELETE FROM tb_reserva_sala_reuniao WHERE id = ?""", id).rowcount
    conn.commit()

def selecionarTodos():
    cursor.execute("SELECT * FROM tb_reserva_sala_reuniao")
    customerList = []

    for row in cursor.fetchall():
        customerList.append(reservas.reserva_sala(row[0], row[1], row[2], row[3], row[4]))

    return customerList