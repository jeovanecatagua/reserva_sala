import sqlite3
import pandas as pd

conn = sqlite3.connect("dados_projeto.db", check_same_thread=False)
cursor = conn.cursor()

query = "select * from tb_reserva_sala_reuniao"
df = pd.read_sql_query(query, conn)

print(df)

conn.close()


# query = "drop table tb_reserva_sala_reuniao"
# cursor.execute(query)

# conn.commit()